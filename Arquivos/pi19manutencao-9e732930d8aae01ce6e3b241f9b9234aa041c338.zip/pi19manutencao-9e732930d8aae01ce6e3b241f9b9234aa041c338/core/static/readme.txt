Thanks for downloading this theme!

Theme Name: Hidayah
Theme URL: https://bootstrapmade.com/hidayah-free-simple-html-template-for-corporate/
Author: BootstrapMade
Author URL: https://bootstrapmade.com